namespace ConsoleApp1.Model;

public class PriceDiscount : AbstractDiscount
{
    public int DiscountPrice { get; set; }
}