namespace ConsoleApp1.Model;

public abstract class AbstractDiscount
{
    
    public static List<AbstractDiscount> Discounts = new();
    
    public DateTime ExpirationDate { get; set; }
    
    public string DiscountCode { get; set; }
    
}