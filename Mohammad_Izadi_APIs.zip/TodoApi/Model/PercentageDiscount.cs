namespace ConsoleApp1.Model;

public class PercentageDiscount : AbstractDiscount
{
    public float DiscountPercentage { get; set; }
    
}