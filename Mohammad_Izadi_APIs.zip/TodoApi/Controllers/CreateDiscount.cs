using ConsoleApp1;
using ConsoleApp1.Apis;
using ConsoleApp1.Model;
using Microsoft.AspNetCore.Mvc;

namespace TodoApi.Controllers;

[ApiController]
[Route("[controller]")]
public class CreateDiscount : ControllerBase
{
    private readonly ILogger<CreateDiscount> _logger;

    public CreateDiscount(ILogger<CreateDiscount> logger)
    {
        _logger = logger;
    }

    [HttpPost(Name = "CreateDiscount")]
    public string Get([FromQuery] CreateDiscountRequest request)
    {
        var discountCode = CodeGenerator.RandomString();
        AbstractDiscount discount;
        if (request.discountType == "PRICE")
        {
            discount = new PriceDiscount
            {
                DiscountCode = discountCode,
                DiscountPrice = (int) request.discountValue,
                ExpirationDate = request.expirationDate
            };
        }
        else
        {
            discount = new PercentageDiscount
            {
                DiscountCode = discountCode,
                DiscountPercentage = request.discountValue,
                ExpirationDate = request.expirationDate
            };
        }
        AbstractDiscount.Discounts.Add(discount);
        return discountCode;
    }

    
}
