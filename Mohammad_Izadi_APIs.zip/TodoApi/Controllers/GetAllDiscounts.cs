using ConsoleApp1;
using ConsoleApp1.Apis;
using ConsoleApp1.Model;
using Microsoft.AspNetCore.Mvc;

namespace TodoApi.Controllers;

[ApiController]
[Route("[controller]")]
public class GetAllDiscounts : ControllerBase
{
    private readonly ILogger<GetAllDiscounts> _logger;

    public GetAllDiscounts(ILogger<GetAllDiscounts> logger)
    {
        _logger = logger;
    }

    [HttpGet(Name = "GetAllDiscounts")]
    public IEnumerable<AbstractDiscount> getAllDiscounts()
    {
        return AbstractDiscount.Discounts.Where(x => x.ExpirationDate > DateTime.Today);
    }
}