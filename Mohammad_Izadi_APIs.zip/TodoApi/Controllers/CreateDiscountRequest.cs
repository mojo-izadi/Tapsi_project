namespace ConsoleApp1.Apis;
using System.ComponentModel.DataAnnotations;

public class CreateDiscountRequest
{
    
    public string discountType { get; set; }
    public float discountValue { get; set; }
    public DateTime expirationDate { get; set; }
}